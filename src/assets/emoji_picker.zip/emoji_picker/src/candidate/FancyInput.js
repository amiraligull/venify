import { Input } from 'baseui/input';

function FancyInput({ placeholder }) {
  return (
    <Input placeholder={placeholder} />
  );
}

export { FancyInput };
